<body>
    <header class="site-header secondary">
        <div class="container nav">
            <a class="brand" href="/"><img src="/build/img/logo.webp" alt="Talk-Hub"></a>
            <button class="nav-toggle" aria-label="Abrir menú" id="navToggle">☰</button>
            <nav class="menu" id="mainNav">
                <a href="/index.php">Home</a>
                <a href="/services.php">services</a>
                <a href="/case_study.php">CaseStudy</a>
                <a class="btn btn-primary" href="#contact">Contacto</a>
            </nav>
        </div>
    </header>